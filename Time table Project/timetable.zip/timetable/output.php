
<!DOCTYPE html>

<html>
    <style>
        select{
            margin-top: 10px;
            padding: 10px;
            border: none;
            background-color: #B6C9F0;
            padding: 5px;
            border-radius: 2px;
            font-family: "Poppins",sans-serif;
}

select option{
  font-family: "Poppins",sans-serif;
  border: none;
}

select option:hover{
  background-color: #8daae6;
}

button{
    font-family: "Poppins",sans-serif;
    font-size: 1em;
    font-weight: 400;
    background-color: #B6C9F0;
    border: none;
    padding: 3px;
    border-radius: 2px;
    width: 50px;
}
</style>
<body>
    
    <form method="POST" action="#.php">
        <center>
    
                <select id="Day" name="Days">
                        
                        <option value="monday">Monday</option>
                        <option value="tuesday">Tuesday</option>
                        <option value="wednesday">Wednesday</option>
                        <option value="thursday">Thursday</option >
                        <option value="friday">Friday</option>
                        <option value="saturday">Saturday</option>
                    </select>
            <button type="submit" name="submit">Go</button>
         
            
        </center>

    </form>
   
        
    </body>

</html>
   
    

        

    
    













