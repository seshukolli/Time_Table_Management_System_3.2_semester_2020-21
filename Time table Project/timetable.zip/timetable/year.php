<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="includes/year.css">
  <title>Years</title>
</head>
<body>

<div class="container">

<div class="card" >
  <div class="face face1">
    <div class="content">
      <h2 class="I">I Year</h2>
      <p class="I">Here you can enter the 1st year time tables.</p>
      <center><button> <a href="1section.php" target="3">Click Here!</a></button></center>
    </div>
   
  </div>
  <div class="face face2">
    <h2>I</h2>
  </div>
</div>

<div class="card">
  <div class="face face1">
    <div class="content">
      <h2 class="II">II Year</h2>
      <p class="II">Here you can enter the 2nd year time tables.</p>
      <center><button> <a href="section.php" target="3">Click Here!</a></button></center>
    </div>
  </div>
  <div class="face face2">
    <h2>II</h2>
  </div>
</div>

<div class="card">
  <div class="face face1">
    <div class="content">
      <h2 class="III">III Year</h2>
      <p class="III">Here you can enter the 3rd year time tables.</p>
      <center><button> <a href="section.php" target="3">Click Here!</a></button></center>
    </div>
  </div>
  <div class="face face2">
    <h2>III</h2>
  </div>
</div>

<div class="card">
  <div class="face face1">
    <div class="content">
      <h2 class="IV">IV Year</h2>
      <p class="IV">Here you can enter the 4th year time tables.</p>
      <center><button> <a href="section.php" target="3">Click Here!</a></button></center>
    </div>
  </div>
  <div class="face face2">
    <h2>IV</h2>
  </div>
</div>



</div>
</body>
</html>