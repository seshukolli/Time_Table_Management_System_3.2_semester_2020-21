<?php

$dbServername="localhost";
$dbUsername="root";
$dbPassword="";
$dbName="timetable";

$conn =mysqli_connect($dbServername,$dbUsername,$dbPassword,$dbName);
?>