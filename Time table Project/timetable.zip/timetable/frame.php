<html>
  <head>
    <title>Homepage</title>
  </head>
    
       <frameset cols="25%,75%" border="0">
         <frame name="2" src="left.php" noresize></frame>
         <frame name="3" src="right.html"></frame>
       </frameset>
</html>

