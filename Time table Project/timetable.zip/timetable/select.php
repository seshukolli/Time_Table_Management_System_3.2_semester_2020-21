<!DOCTYPE html>

<html>
    <head>
        <title>4</title>
    </head>
    <body>
       <center> 
           <label for="Year">Year:</label><br>
           <select name="Year">
            <option>1st</option>
            <option>2nd</option>
            <option>3rd</option>
            <option>4th</option>
           </select><br><br>
           <label for="Year">Sem:</label><br>
        <select name="Semester">
            <option>1st</option>
            <option>2nd</option>
           </select><br><br>
           <label for="Year">Section:</label><br>
        <select name="Section">
            <option>1st</option>
            <option>2nd</option>
            <option>3rd</option>
           </select><br><br>
        <button>Submit</button></center>
    </body>
</html>